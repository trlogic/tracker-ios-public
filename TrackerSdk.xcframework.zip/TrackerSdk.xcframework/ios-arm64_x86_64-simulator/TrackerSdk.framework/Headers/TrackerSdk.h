//
//  TrackerSdk.h
//  TrackerSdk
//
//  Created by Hasan Gözüm on 6.05.2024.
//

#import <Foundation/Foundation.h>
#import <TrackerSdk/DeviceUID.h>


//! Project version number for TrackerSdk.
FOUNDATION_EXPORT double TrackerSdkVersionNumber;

//! Project version string for TrackerSdk.
FOUNDATION_EXPORT const unsigned char TrackerSdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TrackerSdk/PublicHeader.h>


